package finalproject;
import java.sql.*;

public class FinalProject {
    public static void main(String[] args) {
        mainJFrame main = new mainJFrame();
        main.setVisible(true);
    }
}